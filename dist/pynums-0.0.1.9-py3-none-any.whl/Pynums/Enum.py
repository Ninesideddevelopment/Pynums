
class Enum(metaclass=EnumMetaClass):
    pass